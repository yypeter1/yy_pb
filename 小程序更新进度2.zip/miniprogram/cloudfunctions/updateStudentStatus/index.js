const cloud = require('wx-server-sdk');
cloud.init({
  env: 'teacher-sign-in-6gi869h994cf5b13'  // 替换为你的云环境ID
});

exports.main = async (event, context) => {
  try {
    const { classId, studentId, newStatus } = event;
    const db = cloud.database();
    const classesCollection = db.collection('classes');
    
    // 查找指定班级
    const res = await classesCollection.where({
      classId: classId
    }).get();

    if (res.data.length === 0) {
      return { success: false, error: '班级未找到' };
    }

    const classData = res.data[0];
    const students = classData.students;
    const studentIndex = students.findIndex(s => s.studentId === studentId);

    if (studentIndex === -1) {
      return { success: false, error: '学生未找到' };
    }

    // 更新学生状态
    students[studentIndex].status = newStatus;

    // 打印更新前的学生数据
    console.log("Updated students list: ", students);

    // 更新班级数据
    const updateRes = await classesCollection.where({ classId }).update({
      data: {
        students: students
      }
    });

    if (updateRes.stats.updated === 0) {
      return { success: false, error: '更新操作失败' };
    }

    return { success: true };

  } catch (error) {
    console.error('云函数执行错误:', error);
    return { success: false, error: error.message };
  }
};
