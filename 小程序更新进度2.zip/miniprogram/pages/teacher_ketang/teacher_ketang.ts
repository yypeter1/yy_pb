
  Page({
      
    data: {
      showPopupFlag: false,  // 控制悬浮框显示与隐藏
      classId: '' , // 存储输入的班级编号
      courseName: '',
      courseId: '',
      courses: [] , // 存储已添加的课程
      jobId:''
    },
    // 如果 jobId 存在，则查询该教师的课程记录
    // 获取教师ID（假设教师ID存储在本地存储中
    // 点击课程项时跳转到 teacher_addclass 页面
    onShow: function() {
        // 获取本地存储的 jobId
        const jobId = wx.getStorageSync('jobId');
        
        // 如果没有 jobId，跳转到登录页面
        if (!jobId) {
          wx.showToast({
            title: '请先登录',
            icon: 'none'
          });
          wx.navigateTo({
            url: '/pages/student_log/student_log',  // 跳转回登录页面
          });
          return;
        }
    
        // 查询数据库，加载当前教师的课程数据
        wx.cloud.database().collection('courses').where({
          jobId: jobId  // 过滤条件：只查询当前教师的课程
        }).get({
          success: res => {
            // 设置页面数据
            this.setData({
              courses: res.data  // 更新课程数据
            });
          },
          fail: err => {
            wx.showToast({
              title: '加载课程失败',
              icon: 'none'
            });
          }
        });
      },
  onCourseClick: function(event) {
    wx.navigateTo({
      url: '/pages/teacher_addclass/teacher_addclass' // 跳转到 teacher_addclass 页面
    });
  },
  // 显示悬浮框
  showPopup: function() {
    this.setData({
      showPopupFlag: true
    });
  },
     // 课程名称输入处理
  onCourseNameInput: function(event) {
    this.setData({
      courseName: event.detail.value
    });
  },

  // 课程编号输入处理
  onCourseIdInput: function(event) {
    this.setData({
      courseId: event.detail.value
    });
  },
  
  // 添加课程按钮点击处理
  addCourse: function() {
    const { courseName, courseId } = this.data;
    
    // 检查课程名称和课程编号是否为空
    if (!courseName || !courseId) {
      wx.showToast({
        title: '课程名称或课程编号不能为空',
        icon: 'none'
      });
      return;
    }
    const jobId = wx.getStorageSync('jobId');
   wx.cloud.database().collection('courses').add({
     data: {
       courseName: courseName,
       courseId: courseId,
       createTime: new Date(),  // 记录创建时间
       jobId: jobId
     },
     success: res => {
       // 成功后更新页面上的课程列表
       const newCourse = { courseName, courseId };
       const updatedCourses = [...this.data.courses, newCourse];

       this.setData({
         courses: updatedCourses,
         courseName: '',  // 清空输入框
         courseId: '',    // 清空输入框
         showPopupFlag: false  // 隐藏悬浮框
       });

       wx.showToast({
         title: '课程添加成功',
         icon: 'success'
       });
     },
     fail: err => {
       wx.showToast({
         title: '添加课程失败',
         icon: 'none'
       });
     }
   });
 },

  // 删除课程
  deleteCourse: function (event) {
    const index = event.currentTarget.dataset.index;  // 获取点击删除课程的索引
    const courseToDelete = this.data.courses[index];  // 获取该课程的具体信息

    // 获取课程的唯一标识符
    const { courseId } = courseToDelete;

    // 从云数据库中删除课程
    wx.cloud.database().collection('courses').where({
      courseId: courseId  // 根据课程编号查找
    }).remove({
      success: res => {
        // 删除成功后，更新页面上的课程列表
        const updatedCourses = this.data.courses.filter((_, i) => i !== index);  // 删除课程项
        this.setData({
          courses: updatedCourses
        });

        // 显示删除成功提示
        wx.showToast({
          title: '课程已删除',
          icon: 'success'
        });
      },
      fail: err => {
        // 删除失败的提示
        wx.showToast({
          title: '删除课程失败',
          icon: 'none'
        });
      }
    });
  },
  // 返回上一页 
  goBack: function() { wx.navigateBack({ delta: 1 }); 
},
});
  
  
  