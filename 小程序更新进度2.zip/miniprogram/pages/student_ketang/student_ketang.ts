
Page({
    data: {
      classId: '',
      className: '',
      studentId:'',
      showPopupFlag: false,
      joinedClasses: [] , // 存储已加入的班级
    },
  
    // 获取输入框中的班级编号
    onClassIdInput: function(e) {
      this.setData({
        classId: e.detail.value
      });
    },
  
    // 加入班级
    joinClass: function() {
      const { classId } = this.data;
      const studentId = wx.getStorageSync('studentId')
      if (!classId) {
        wx.showToast({
          title: '请输入班级编号',
          icon: 'none'
        });
        return;
      }
  
      // 校验学生是否已加入该班级
      wx.cloud.database().collection('joinedClasses').where({
        studentId: studentId,
        classId: classId,
      }).get({
        success: res => {
          if (res.data.length > 0) {
            wx.showToast({
              title: '您已加入该班级',
              icon: 'none'
            });
            return;
          } else {
            // 查询班级信息并将学生加入班级
            wx.cloud.database().collection('classes').where({
              classId: classId
            }).get({
              success: res => {
                if (res.data.length === 0) {
                  wx.showToast({
                    title: '班级编号无效',
                    icon: 'none'
                  });
                } else {
                  const classData = res.data[0];
                  const name = wx.getStorageSync('name')
                  wx.setStorageSync('studentId', studentId);
                  wx.cloud.database().collection('classes').doc(classData._id).update({
                    data: {
                      students: wx.cloud.database().command.push({
                        studentId: studentId,
                        studentName:name  // 添加学生名字
                      })
                    },
                    success: () => {
                      wx.showToast({
                        title: '已加入班级',
                        icon: 'success'
                      });
  
                      wx.cloud.database().collection('joinedClasses').add({
                        data: {
                          name:name,
                          studentId: studentId,
                          classId: classData.classId,
                          className: classData.className
                        },
                        success: () => {
                          this.setData({
                            className: classData.className,
                            showPopupFlag: false
                          });
                          this.updateJoinedClasses();
                        },
                        fail: err => {
                          wx.showToast({
                            title: '加入班级失败',
                            icon: 'none'
                          });
                        }
                      });
                    },
                    fail: err => {
                      wx.showToast({
                        title: '加入班级失败',
                        icon: 'none'
                      });
                    }
                  });
                }
              },
              fail: err => {
                wx.showToast({
                  title: '查询失败',
                  icon: 'none'
                });
              }
            });
          }
        }
      });
    },
  
    // 获取已加入的班级
    updateJoinedClasses: function() {
      const studentId = wx.getStorageSync('studentId');
      if (studentId) {
        wx.cloud.database().collection('joinedClasses').where({
          studentId: studentId
        }).get({
          success: res => {
            this.setData({
              joinedClasses: res.data
            });
          },
          fail: err => {
            wx.showToast({
              title: '加载班级失败',
              icon: 'none'
            });
          }
        });
      }
    },
  
    // 删除班级
    deleteClass: function(e) {
      const { classId } = e.currentTarget.dataset;
      const studentId = wx.getStorageSync('studentId');
  
      if (!studentId) {
        wx.showToast({
          title: '请先登录',
          icon: 'none'
        });
        return;
      }
  
      wx.cloud.database().collection('joinedClasses').where({
        studentId: studentId,
        classId: classId
      }).remove({
        success: () => {
          wx.showToast({
            title: '成功删除班级',
            icon: 'success'
          });
  
          wx.cloud.database().collection('classes').where({
            classId: classId
          }).get({
            success: res => {
              if (res.data.length > 0) {
                const classDocId = res.data[0]._id;
                wx.cloud.database().collection('classes').doc(classDocId).update({
                  data: {
                    students: wx.cloud.database().command.pull(studentId)
                  },
                  success: () => {
                    this.updateJoinedClasses();
                  },
                  fail: err => {
                    wx.showToast({
                      title: '移除班级成员失败',
                      icon: 'none'
                    });
                  }
                });
              }
            },
            fail: err => {
              wx.showToast({
                title: '查询班级失败',
                icon: 'none'
              });
            }
          });
        },
        fail: err => {
          wx.showToast({
            title: '删除班级失败',
            icon: 'none'
          });
        }
      });
    },
  
    // 进入签到页面
    enterSigninPage: function(e) {
      const { classId } = e.currentTarget.dataset;
      const studentId = wx.getStorageSync('studentId'); 
      const className= wx.getStorageSync('className'); 
      // 跳转到签到页面并传递 classId 和 studentId
  wx.navigateTo({
    url: `/pages/student_signin/student_signin?classId=${classId}&studentId=${studentId}&className=${className}`
  });
    },
  
    // 点击显示加入班级弹窗
    showPopup: function() {
      this.setData({
        showPopupFlag: true
      });
    },
  
    // 页面加载时显示已加入班级
    onShow: function() {
      const studentId = wx.getStorageSync('studentId');
      if (!studentId) {
        wx.showToast({
          title: '请先登录',
          icon: 'none'
        });
        wx.navigateTo({
          url: '/pages/student_login/student_login',
        });
        return;
      }
  
      this.updateJoinedClasses();
    },
    goBack: function() { wx.navigateBack({ delta: 1 
    }); 
    },
  });
  