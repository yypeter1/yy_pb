Page({
    data: {
      attendanceCode: '',
      classId: '',
      studentId: '',
      className: '', // 添加 className 用来保存班级名称
    },
  
    onLoad: function(options) {
      const classId = options.classId;
      const studentId = options.studentId;
      const className = options.className; // 从页面参数中获取 className
  
      this.setData({
        classId: classId,
        studentId: studentId,
        className: className, // 设置 className 数据
      });
    },
  
    onAttendanceCodeInput: function(e) {
      this.setData({
        attendanceCode: e.detail.value
      });
    },
  
    onSigninTap: function() {
      const { attendanceCode, classId, studentId, className } = this.data;
  
      if (!attendanceCode) {
        wx.showToast({
          title: '请输入考勤码',
          icon: 'none'
        });
        return;
      }
  
      wx.cloud.database().collection('AttendanceCodes')
        .where({ classId, attendanceCode })
        .get()
        .then(res => {
          if (res.data.length === 0) {
            wx.showToast({
              title: '考勤码无效或已过期',
              icon: 'none'
            });
            return;
          }
  
          const attendance = res.data[0];
          const currentTime = new Date().getTime();
          const startTime = new Date(attendance.startTime).getTime();
          const endTime = new Date(attendance.endTime).getTime();
  
          if (currentTime < startTime || currentTime > endTime) {
            wx.showToast({
              title: '考勤时间已结束',
              icon: 'none'
            });
            return;
          }
  
          // 保存签到记录到 AttendanceRecords 集合，并添加 className 字段
          wx.cloud.database().collection('AttendanceRecords')
            .add({
              data: {
                classId: classId,
                className: className, // 添加 className 字段
                studentId: studentId,
                attendanceCode: attendanceCode,
                signinTime: new Date(),
                status: '出勤', // 设置签到时的出勤状态
              }
            })
            .then(() => {
              wx.showToast({
                title: '签到成功',
                icon: 'success'
              });
  
              // 更新 AttendanceCodes 中学生的状态
              const updatedStudents = attendance.students.map(student => {
                if (student.studentId === studentId) {
                  student.status = '出勤'; // 将学生状态更新为“出勤”
                }
                return student;
              });
  
              // 更新 AttendanceCodes 数据
              wx.cloud.database().collection('AttendanceCodes')
                .doc(attendance._id)  // 获取当前考勤记录的 _id
                .update({
                  data: {
                    students: updatedStudents,  // 更新学生状态
                  },
                  success: () => {
                    console.log('学生状态更新成功');
                  },
                  fail: (err) => {
                    wx.showToast({
                      title: '更新学生状态失败',
                      icon: 'none'
                    });
                    console.error('更新学生状态失败:', err);
                  }
                });
            })
            .catch(err => {
              wx.showToast({
                title: '签到失败，请稍后再试',
                icon: 'none'
              });
              console.error('签到记录保存失败:', err);
            });
        })
        .catch(err => {
          wx.showToast({
            title: '查询失败，请稍后再试',
            icon: 'none'
          });
          console.error('查询失败:', err);
        });
    },
  
    // 查看考勤记录按钮点击事件
    onCheckRecordTap: function() {
      const { classId, studentId, className } = this.data;
  
      // 跳转到考勤记录页面，并传递班级ID、学生ID和班级名称
      wx.navigateTo({
        url: `/pages/attendance_record/attendance_record?classId=${classId}&studentId=${studentId}&className=${className}`,
      });
    },
    goBack: function() { wx.navigateBack({ delta: 1 
    }); 
    },
  });
  