Page({
    data: {
      classId: '',
      attendanceId: '',     // 新增字段存储attendanceId
      students: [],         // 存储所有学生的考勤信息
      filteredStudents: [], // 用于过滤后的学生列表
    },
  
    onLoad: function(options) {
      const classId = options.classId;
      const className = options.className;
      const attendanceId = options.attendanceId;  // 获取传递过来的attendanceId
      this.setData({
        classId: classId,
        className: className,
        attendanceId: attendanceId  // 保存attendanceId
      });
  
      // 使用 watch 监听AttendanceCodes集合数据变化
      const db = wx.cloud.database();
      db.collection('AttendanceCodes').where({
        classId: classId,
        _id: attendanceId  // 添加attendanceId作为查询条件
      }).watch({
        onChange: (snapshot) => {
          // 每当数据发生变化时，自动更新学生列表
          if (snapshot.docChanges.length > 0) {
            const updatedStudents = snapshot.docs[0].students || [];
            this.setData({
              students: updatedStudents,
              filteredStudents: updatedStudents
            });
          }
        },
        onError: (err) => {
          console.error('监听数据变化失败:', err);
        }
      });
  
      // 初次加载考勤记录
      db.collection('AttendanceCodes').where({
        classId: classId,
        _id: attendanceId  // 添加attendanceId作为查询条件
      }).get({
        success: res => {
          if (res.data.length > 0) {
            const students = res.data[0].students || [];
            this.setData({
              students: students,
              filteredStudents: students  // 初始状态下展示所有学生
            });
          } else {
            wx.showToast({
              title: '未找到考勤记录',
              icon: 'none'
            });
          }
        },
        fail: err => {
          wx.showToast({
            title: '加载考勤数据失败',
            icon: 'none'
          });
        }
      });
    },
    goBack: function() { wx.navigateBack({ delta: 1 
    }); 
    },
    // 修改学生状态
    onModifyStatus: function(e) {
      const studentId = e.currentTarget.dataset.id;
      const student = this.data.students.find(s => s.studentId === studentId);
  
      wx.showActionSheet({
        itemList: ['出勤', '缺勤', '请假'],
        success: (res) => {
          const newStatus = ['出勤', '缺勤', '请假'][res.tapIndex];
          this.updateStudentStatus(studentId, newStatus);
        },
        fail: (err) => {
          console.log(err);
        }
      });
    },
  
    // 更新学生签到状态
    updateStudentStatus: function(studentId, newStatus) {
      // 更新学生的状态
      const students = this.data.students.map(student => {
        if (student.studentId === studentId) {
          student.status = newStatus;  // 更新状态
        }
        return student;
      });
  
      this.setData({
        students: students,
        filteredStudents: students
      });
  
      // 更新AttendanceCodes集合中的学生状态
      wx.cloud.database().collection('AttendanceCodes').where({
        classId: this.data.classId,
        _id: this.data.attendanceId  // 添加attendanceId作为查询条件
      }).update({
        data: {
          students: students  // 更新班级中的学生考勤信息
        },
        success: () => {
          wx.showToast({
            title: '状态更新成功',
            icon: 'success'
          });
        },
        fail: () => {
          wx.showToast({
            title: '状态更新失败',
            icon: 'none'
          });
        }
      });
    }
  });
  