Page({
     
    data: {
      showPopupFlag: false,  // 控制悬浮框显示与隐藏
      classId: '',  // 存储输入的班级编号
      className:'',
      courseName: '',
      courseId: '',
      classes: []  // 存储已添加的课程
    },
  
    onShow: function() {
        const jobId = wx.getStorageSync('jobId');
        if (!jobId) {
          wx.showToast({
            title: '请先登录',
            icon: 'none'
          });
          wx.navigateTo({
            url: '/pages/teacher_log/teacher_log',  // 跳转回登录页面
          });
          return;
        }
      
        // 从云数据库中查询班级数据
        wx.cloud.database().collection('classes').where({
          jobId: jobId  // 根据当前教师的 jobId 查询班级
        }).get({
          success: res => {
            if (res.data.length > 0) {
              // 更新页面上的课程数据
              this.setData({
                classes: res.data.map(item => ({
                  className: item.className,
                  classId: item.classId
                }))
              });
            } else {
              wx.showToast({
                title: '暂无班级数据',
                icon: 'none'
              });
            }
          },
          fail: err => {
            wx.showToast({
              title: '加载班级失败',
              icon: 'none'
            });
            console.error('获取班级数据失败：', err);
          }
        });
      },
      
  
    // 显示悬浮框
    showPopup: function() {
      this.setData({
        showPopupFlag: true
      });
    },
  
    // 课程名称输入处理
    onCourseNameInput: function(event) {
      this.setData({
        className: event.detail.value
      });
    },
  
    // 课程编号输入处理
    onCourseIdInput: function(event) {
      this.setData({
        classId: event.detail.value
      });
    },
  
    // 添加课程按钮点击处理
    addCourse: function() {
      const { className,classId } = this.data;
      // 检查课程名称和课程编号是否为空
      if (!className || !classId) {
        wx.showToast({
          title: '课程名称或课程编号不能为空',
          icon: 'none'
        });
        return;
      }
  
      // 获取教师 ID
      const jobId = wx.getStorageSync('jobId');
  
      // 上传课程信息到云数据库
      wx.cloud.database().collection('classes').add({
        data: {
          jobId: jobId,  // 关联教师的 jobId
          className: className,
          classId: classId,
          createTime: new Date()  // 记录创建时间
        },
        success: res => {
          // 更新课程数据并关闭悬浮框
          const newClass = { className, classId };
          const updatedClass = [...this.data.classes, newClass];
  
          this.setData({
            classes: updatedClass,
            className: '',  // 清空输入框
            classId: '',    // 清空输入框
            showPopupFlag: false, // 隐藏悬浮框
            jobId:jobId
          });
  
          wx.showToast({
            title: '课程添加成功',
            icon: 'success'
          });
        },
        fail: err => {
          wx.showToast({
            title: '添加课程失败',
            icon: 'none'
          });
        }
      });
    },
    // 跳转到考勤管理页面
    Attendence: function (event) {
        console.log('点击了考勤管理按钮');
        const className = event.currentTarget.dataset.className;
        const classId = event.currentTarget.dataset.classId;

  // 跳转到考勤管理页面，并传递班级信息
  wx.navigateTo({
    url: `/pages/teacher_Attendence/teacher_Attendence?className=${className}&classId=${classId}`,
  });
},
  // 跳转到班级详情页面
  viewClassDetails: function(event) {
    const className = event.currentTarget.dataset.className;
    const classId = event.currentTarget.dataset.classId;
    wx.navigateTo({
      url: `/pages/class_details/class_details?className=${className}&classId=${classId}`,
    });
  },
    // 删除课程
    deleteCourse: function(event) {
      const index = event.currentTarget.dataset.index;
      const classes = this.data.classes[index];
      const classId = classes.classId;  // 获取要删除的课程编号
  
      // 获取教师 ID
      const jobId = wx.getStorageSync('jobId');
      if (!jobId) {
        wx.showToast({
          title: '请先登录',
          icon: 'none'
        });
        return;
      }
  
      // 删除数据库中的课程
      wx.cloud.database().collection('classes').where({
        jobId: jobId,
        classId: classId  // 删除指定课程编号的数据
      }).remove({
        success: res => {
          // 删除课程后，更新页面上的课程列表
          const updatedCourses = this.data.classes.filter((_, i) => i !== index);
          this.setData({
            classes: updatedCourses
          });
  
          wx.showToast({
            title: '课程已删除',
            icon: 'success'
          });
        },
        fail: err => {
          wx.showToast({
            title: '删除课程失败',
            icon: 'none'
          });
        }
      });
    },
    // 返回上一页
  goBack: function() {
    wx.navigateBack({
      delta: 1 // 默认返回上一页
    });
  },
  });
  