Page({
    onRegister: function () {
        wx.navigateTo({
          url: '/pages/teacher_register/teacher_register'
        });
    },
    data: {
      phone: '',
      jobId:'',
      password: '',
      selectedOption: '手机',       // 默认选项
      placeholder: '请输入手机号',  // 输入框提示文字
      Value: '',               // 输入框值
      showPicker: false             // 控制下拉框是否显示
    },
 // 点击输入框旁边的小箭头，显示或隐藏下拉框
 
 onPickerClick: function() {
    this.setData({
      showPicker: !this.data.showPicker // 切换下拉框的显示状态
    });
  },
  // 选择下拉框中的选项（手机号或学号）
  onOptionSelect: function(event) {
    const selectedOption = event.currentTarget.dataset.option;
    this.setData({
      selectedOption: selectedOption,
      placeholder: selectedOption === '手机' ? '请输入手机号' : '请输入工号',
      showPicker: false, // 选择后隐藏下拉框
      inputValue: ''     // 清空输入框内容
    });
  },

  // 处理输入框内容
  onInput: function(event) {
    this.setData({
      inputValue: event.detail.value
    });
  },

// 获取手机号
  inputValue: function(e) {
    this.setData({
      Value: e.detail.value,
    });
  },

  // 获取密码
  onPasswordInput: function(e) {
    this.setData({
      password: e.detail.value
    });
  },
   // 登录按钮点击事件
  onLogin: function() {
    const {Value, password } = this.data;
      // 获取当前教师的唯一标识（手机号、工号等
      
    // 校验输入
    if ( !Value|| !password) {
      wx.showToast({
        title: '请输入手机号或工号和密码',
        icon: 'none'
      });
      return;
    }

    // 查询数据库，验证手机号、工号和密码是否匹配
    wx.cloud.database().collection('users').where({
        $or: [
            { phone: Value },    // 匹配手机号
            { jobId: Value }     // 匹配工号
          ]
    }).get({
      success: res => {
        if (res.data.length === 0) {
            
          wx.showToast({
            title: '该手机号或工号未注册',
            icon: 'none'
          });
          return;
        }

        // 验证密码是否匹配
        const user = res.data[0];
        if (user.password === password) {
            // 存储jobId
      wx.setStorageSync('jobId', user.jobId);  // 将jobId存储在本地
          wx.showToast({
            title: '登录成功',
            icon: 'success'
          });
          // 登录成功后跳转到主页面
          wx.navigateTo({
            url: '/pages/teacher_ketang/teacher_ketang'
          });
        } else {
          wx.showToast({
            title: '密码错误',
            icon: 'none'
          });
        }
      },
      fail: err => {
        wx.showToast({
          title: '登录失败',
          icon: 'none'
        });
      }
    });
  },
  // 返回上一页 
  goBack: function() { wx.navigateBack({ delta: 1 
}); 
},
});
  
  