// index.ts
// 获取应用实例
Page({
    onImageClick: function () {
      wx.navigateTo({
        url: '/pages/student_logs/student_logs'
      });
    },
    onImageClick_teacher: function () {
        wx.navigateTo({
          url: '/pages/teacher_logs/teacher_logs'
        });
      }
});








  
  
  
