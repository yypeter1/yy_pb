Page({
    data: {
      classId: '',  // 班级ID
      className: '',  // 班级名称
      students: [],  // 班级的学生列表
      showAddStudentPopupFlag: false,  // 控制弹出框显示与隐藏
      studentId: '',  // 学生ID输入
    },
  
    onLoad: function(options) {
      const { className, classId } = options;
      this.setData({
        className: className,
        classId: classId
      });
  
      // 假设从云数据库加载班级的学生数据
      this.loadClassStudents(classId);
    },
  
    // 加载班级学生数据
    loadClassStudents: function(classId) {
      wx.cloud.database().collection('classes')
        .where({ classId: classId })  // 按班级ID查询
        .get({
          success: res => {
            if (res.data.length > 0) {
              const classData = res.data[0]; // 假设每个班级的文档只有一个
              const students = classData.students || []; // 获取班级中的学生数组
              this.setData({
                students: students
              });
            } else {
              wx.showToast({
                title: '该班级没有数据',
                icon: 'none'
              });
            }
          },
          fail: err => {
            wx.showToast({
              title: '加载学生数据失败',
              icon: 'none'
            });
            console.error('获取学生数据失败：', err);
          }
        });
    },
  
    // 搜索框输入处理
    onSearchInput: function(event) {
      const searchValue = event.detail.value.toLowerCase();
      const filteredStudents = this.data.students.filter(student => {
        return student.studentId.includes(searchValue); // 只匹配学号
      });
      this.setData({
        students: filteredStudents
      });
    },
  
    // 显示添加学生弹出框
    showAddStudentPopup: function() {
      this.setData({
        showAddStudentPopupFlag: true
      });
    },
  
    // 学生学号输入处理
    onStudentIdInput: function(event) {
      this.setData({
        studentId: event.detail.value
      });
    },
  
    // 添加学生
    addStudent: function() {
      const { studentId, classId } = this.data;
      if (!studentId) {
        wx.showToast({
          title: '学号不能为空',
          icon: 'none'
        });
        return;
      }

      // 获取当前班级信息
      wx.cloud.database().collection('classes')
        .where({ classId: classId })
        .get({
          success: res => {
            if (res.data.length > 0) {
              const classData = res.data[0];
              const students = classData.students || [];
  
              // 如果学生已经存在，则提示
              if (students.some(student => student.studentId === studentId)) {
                wx.showToast({
                  title: '该学生已存在',
                  icon: 'none'
                });
                return;
              }
  
              // 添加学生
              students.push({ studentId, studentName: '' });  // 学生名字暂时为空
              wx.cloud.database().collection('classes').doc(classData._id).update({
                data: {
                  students: students
                },
                success: () => {
                  this.setData({
                    students: students,
                    studentId: '',
                    showAddStudentPopupFlag: false
                  });
                  wx.showToast({
                    title: '添加学生成功',
                    icon: 'success'
                  });
                },
                fail: err => {
                  wx.showToast({
                    title: '添加学生失败',
                    icon: 'none'
                  });
                  console.error('添加学生失败：', err);
                }
              });
            }
          },
          fail: err => {
            wx.showToast({
              title: '加载班级信息失败',
              icon: 'none'
            });
            console.error('加载班级信息失败：', err);
          }
        });
    },
  
    // 删除学生
    deleteStudent: function(event) {
      const index = event.currentTarget.dataset.index;
      const student = this.data.students[index];
      const studentId = student.studentId;  // 获取要删除的学生ID
  
      // 获取当前班级信息
      wx.cloud.database().collection('classes')
        .where({ classId: this.data.classId })
        .get({
          success: res => {
            if (res.data.length > 0) {
              const classData = res.data[0];
              const students = classData.students.filter(s => s.studentId !== studentId);
  
              // 更新学生数据
              wx.cloud.database().collection('classes').doc(classData._id).update({
                data: {
                  students: students
                },
                success: () => {
                  this.setData({
                    students: students
                  });
                  wx.showToast({
                    title: '学生已删除',
                    icon: 'success'
                  });
                },
                fail: err => {
                  wx.showToast({
                    title: '删除学生失败',
                    icon: 'none'
                  });
                  console.error('删除学生失败：', err);
                }
              });
            }
          },
          fail: err => {
            wx.showToast({
              title: '加载班级信息失败',
              icon: 'none'
            });
            console.error('加载班级信息失败：', err);
          }
        });
    },
    goBack: function() { wx.navigateBack({ delta: 1 
    }); 
    },
  });
  