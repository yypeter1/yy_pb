Page({
    data: {
      classId: '', // 班级ID
      className: '', // 班级名称
      attendanceRecords: [], // 存储考勤记录
      studentId: ''  // 学生ID（用于检查签到状态）
    },
  
    // 页面加载时获取数据
    onLoad: function(options) {
      const { classId, studentId } = options;
  
      this.setData({
        classId: classId,
        studentId: studentId
      });
  
      // 获取班级名称
      this.getClassName(classId);
  
      // 加载班级的考勤记录
      this.loadAttendanceRecords(classId);
    },
  
    // 获取班级名称
    getClassName: function(classId) {
      wx.cloud.database().collection('classes')
        .where({ classId: classId })  // 根据班级ID查询
        .get()
        .then(res => {
          if (res.data.length > 0) {
            const className = res.data[0].className;  // 假设字段是 className
            this.setData({
              className: className
            });
          } else {
            wx.showToast({
              title: '未找到该班级',
              icon: 'none'
            });
          }
        })
        .catch(err => {
          wx.showToast({
            title: '获取班级信息失败',
            icon: 'none'
          });
          console.error('获取班级信息失败：', err);
        });
    },

  
    // 加载班级考勤记录
    loadAttendanceRecords: function(classId) {
      wx.cloud.database().collection('AttendanceCodes')
        .where({ classId: classId })  // 查询该班级的所有考勤记录
        .get()
        .then(res => {
          console.log('获取到的考勤记录:', res.data);
          if (res.data.length > 0) {
            const attendanceRecords = res.data.map(record => {
              record.status = '缺勤'; // 默认状态为"缺勤"
              record.students.forEach(student => {
                if (student.studentId === this.data.studentId && student.status === '出勤') {
                  record.status = '出勤';
                }
              });
              return record;
            });
            this.setData({
              attendanceRecords: attendanceRecords
            });
          } else {
            wx.showToast({
              title: '暂无考勤记录',
              icon: 'none'
            });
          }
        })
        .catch(err => {
          wx.showToast({
            title: '加载考勤记录失败',
            icon: 'none'
          });
          console.error('加载考勤记录失败：', err);
        });
    },
    goBack: function() { wx.navigateBack({ delta: 1 
    }); 
    },
  });
  