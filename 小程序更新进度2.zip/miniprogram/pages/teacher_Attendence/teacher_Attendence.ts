Page({
    data: {
      _id: '',
      className: '',
      classId: '',
      attendanceCount: 0,
      attendanceTime: '',
      attendanceRate: 0,
      popupVisible: false,
      attendanceCode: '',
      duration: 0,
      attendanceList: [],  // 存储每次考勤记录的数组
    },
  
    // 页面加载时获取班级信息和本地存储的考勤记录
    onLoad: function (options) {
      const className = options.className;
      const classId = options.classId;
      this.setData({
        className: className,
        classId: classId
      });
  
      // 加载本地存储的考勤记录
      const storedAttendanceList = wx.getStorageSync('attendanceList') || [];
      this.setData({
        attendanceList: storedAttendanceList
      });
    },
  
    // 打开考勤设置弹窗
    showPopup() {
      this.setData({ popupVisible: true });
    },
  
    // 获取输入的考勤码
    onCodeInput(event) {
      this.setData({ attendanceCode: event.detail.value });
    },
  
    // 获取输入的持续时间
    onDurationInput(event) {
      this.setData({ duration: event.detail.value });
    },
  
    // 提交考勤设置
    submitAttendanceSettings() {
      const currentDate = new Date();
      const hours = currentDate.getHours();
      const minutes = currentDate.getMinutes();
      const seconds = currentDate.getSeconds();
      const formattedTime = `${currentDate.getFullYear()}-${(currentDate.getMonth() + 1).toString().padStart(2, '0')}-${currentDate.getDate().toString().padStart(2, '0')} ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  
      // 从本地存储获取最新的考勤记录，计算当前考勤次数
      const storedAttendanceList = wx.getStorageSync('attendanceList') || [];
      const attendanceCount = storedAttendanceList.length + 1;  // 计算新的考勤次数
      const attendanceRate = this.calculateAttendanceRate(attendanceCount);  // 假设出勤率计算
  
      // 获取班级名称
      wx.cloud.database().collection('classes').where({
        classId: this.data.classId  // 使用 classId 查找班级名称
      }).get({
        success: res => {
          if (res.data.length === 0) {
            wx.showToast({
              title: '班级未找到',
              icon: 'none'
            });
            return;
          }
          const students = res.data[0].students || [];  // 获取班级学生数据
          const studentsAttendance = students.map(student => ({
            studentId: student.studentId,
            studentName: student.studentName,
          }));
  
          // 获取班级名称
          const className = res.data[0].className;
  
          // 将考勤设置上传到数据库
          wx.cloud.database().collection('AttendanceCodes').add({
            data: {
              attendanceCode: this.data.attendanceCode,
              classId: this.data.classId,
              className: className,  // 添加 className
              students: studentsAttendance,  // 保存学生签到信息
              duration: this.data.duration,
              startTime: formattedTime,  // 设置开始时间
              endTime: new Date(currentDate.getTime() + this.data.duration * 60000).toISOString(),  // 计算结束时间
              status: 'active'  // 标记为活动状态
            },
            success: res => {
              console.log('考勤码设置成功:', res);
  
              const newAttendance = {
                _id: res._id,  // 获取新记录的 _id
                attendanceCount,
                attendanceTime: formattedTime,
                attendanceRate
              };
  
              const newAttendanceList = [...storedAttendanceList, newAttendance];
              this.setData({
                attendanceList: newAttendanceList,
                attendanceCount,
                attendanceTime: formattedTime,
                attendanceRate,
                popupVisible: false  // 关闭弹窗
              });
  
              // 保存到本地存储
              wx.setStorageSync('attendanceList', newAttendanceList);
              wx.showToast({
                title: '考勤设置成功',
                icon: 'success'
              });
            },
            fail: err => {
              console.error('考勤码设置失败:', err);
              wx.showToast({
                title: '设置失败',
                icon: 'none'
              });
            }
          });
        },
        fail: err => {
          console.error('查询班级信息失败:', err);
          wx.showToast({
            title: '查询班级信息失败',
            icon: 'none'
          });
        }
      });
    },
  
    // 出勤率计算逻辑
    calculateAttendanceRate(count) {
      return count * 10 > 100 ? 100 : count * 10;  // 示例：每次增加10%的出勤率
    },
  
    // 删除考勤记录
    deleteAttendanceRecord(e) {
      const index = e.currentTarget.dataset.index;
      const recordId = this.data.attendanceList[index]._id;  // 获取该记录的 _id
  
      if (!recordId) {
        console.error('没有找到考勤记录的 _id');
        wx.showToast({
          title: '无法删除记录',
          icon: 'none'
        });
        return;
      }
  
      console.log('准备删除的记录ID:', recordId);  // 打印要删除的 _id
  
      // 从数据库中删除考勤记录
      wx.cloud.database().collection('AttendanceCodes').doc(recordId).remove({
        success: res => {
          console.log('考勤记录删除成功:', res);
  
          // 删除本地记录
          const newAttendanceList = this.data.attendanceList.filter((item, i) => i !== index);
          this.setData({
            attendanceList: newAttendanceList
          });
  
          // 更新本地存储
          wx.setStorageSync('attendanceList', newAttendanceList);
  
          // 删除成功后，重新从数据库中加载考勤记录
          wx.cloud.database().collection('AttendanceCodes').where({
            classId: this.data.classId  // 根据 classId 获取考勤记录
          }).get({
            success: res => {
              this.setData({
                attendanceList: res.data  // 更新考勤记录列表
              });
            },
            fail: err => {
              console.error('获取考勤记录失败:', err);
              wx.showToast({
                title: '获取考勤记录失败',
                icon: 'none'
              });
            }
          });
  
          wx.showToast({
            title: '删除成功',
            icon: 'success'
          });
        },
        fail: err => {
          console.error('考勤记录删除失败:', err);
          wx.showToast({
            title: '删除失败',
            icon: 'none'
          });
        }
      });
    },
  
    // 获取考勤记录的 _id 并跳转
    check: function (e) {
      const attendanceId = e.currentTarget.dataset.id;  // 获取点击项的 _id
      wx.navigateTo({
        url: `/pages/attendanceDetail/attendanceDetail?attendanceId=${attendanceId}&attendanceCode=${this.data.attendanceCode}&classId=${this.data.classId}&className=${this.data.className}`
      });
    },
  
    // 关闭考勤设置弹窗
    closePopup() {
      this.setData({
        popupVisible: false
      });
    },
  
    // 返回上一页
    goBack: function () {
      wx.navigateBack({ delta: 1 });
    },
  });
  