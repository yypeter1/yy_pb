// index.ts
// 获取应用实例
Page({
    onImageClick: function () {
      wx.navigateTo({
        url: '/pages/student_logs/student_logs'
      });
    }
});
  
  
  
