Page({
    onRegister: function () {
        wx.navigateTo({
          url: '/pages/student_register/student_register'
        });
    },
    data: {
      username: '',
      password: '',
      selectedOption: '手机',       // 默认选项
      placeholder: '请输入手机号',  // 输入框提示文字
      inputValue: '',               // 输入框值
      showPicker: false             // 控制下拉框是否显示
    },
 // 点击输入框旁边的小箭头，显示或隐藏下拉框
 onPickerClick: function() {
    this.setData({
      showPicker: !this.data.showPicker // 切换下拉框的显示状态
    });
  },
  // 选择下拉框中的选项（手机号或学号）
  onOptionSelect: function(event) {
    const selectedOption = event.currentTarget.dataset.option;
    this.setData({
      selectedOption: selectedOption,
      placeholder: selectedOption === '手机' ? '请输入手机' : '请输入学号',
      showPicker: false, // 选择后隐藏下拉框
      inputValue: ''     // 清空输入框内容
    });
  },
  // 处理输入框内容
  onInput: function(event) {
    this.setData({
      inputValue: event.detail.value
    });
  },
    // 处理用户名输入
    onUsernameInput: function(event) {
      this.setData({
        username: event.detail.value
      });
    },
  
    // 处理密码输入
    onPasswordInput: function(event) {
      this.setData({
        password: event.detail.value
      });
    },
    // 登录按钮点击事件
    onLogin: function() {
      const { username, password } = this.data;
  
      if (!username || !password) {
        wx.showToast({
          title: '用户名或密码不能为空',
          icon: 'none'
        });
        return;
      }
  
      // 模拟登录请求
      wx.showToast({
        title: '登录中...',
        icon: 'loading',
        duration: 1500
      });
  
      // 假设登录成功
      setTimeout(() => {
        wx.showToast({
          title: '登录成功',
          icon: 'success'
        });
        // 跳转到首页或其他页面
        wx.redirectTo({
          url: '/pages/student_ketang/student_ketang'
        });
      }, 1500);
    }
  });
  
  