
  Page({
    data: {
      showPopupFlag: false,  // 控制悬浮框显示与隐藏
      classId: '' , // 存储输入的班级编号
      courseName: '',
      courseId: '',
      courses: []  // 存储已添加的课程
    },
    // 点击课程项时跳转到 teacher_addclass 页面
  onCourseClick: function(event) {
    wx.navigateTo({
      url: '/pages/teacher_addclass/teacher_addclass' // 跳转到 teacher_addclass 页面
    });
  },
  // 显示悬浮框
  showPopup: function() {
    this.setData({
      showPopupFlag: true
    });
  },
     // 课程名称输入处理
  onCourseNameInput: function(event) {
    this.setData({
      courseName: event.detail.value
    });
  },

  // 课程编号输入处理
  onCourseIdInput: function(event) {
    this.setData({
      courseId: event.detail.value
    });
  },

  // 添加课程按钮点击处理
  addCourse: function() {
    const { courseName, courseId } = this.data;
    // 检查课程名称和课程编号是否为空
    if (!courseName || !courseId) {
      wx.showToast({
        title: '课程名称或课程编号不能为空',
        icon: 'none'
      });
      return;
    }

    // 模拟添加课程的请求
    wx.showToast({
      title: '课程添加成功',
      icon: 'success'
    });
     // 上传班级信息到云数据库
     wx.cloud.database().collection('classes').add({
        data: {
          name: courseName,
          id: courseId
        },
        success: res => {
          wx.showToast({
            title: '班级创建成功',
            icon: 'success'
          });
        },
        fail: err => {
          wx.showToast({
            title: '创建失败',
            icon: 'none'
          });
        }
      });
    // 这里可以继续处理添加课程的逻辑，例如向服务器发送请求
 // 将新课程添加到课程列表
 const newCourse = { courseName, courseId };
 const updatedCourses = [...this.data.courses, newCourse];

 // 更新课程数据并关闭悬浮框
 this.setData({
   courses: updatedCourses,
   courseName: '',  // 清空输入框
   courseId: '',    // 清空输入框
   showPopupFlag: false  // 隐藏悬浮框
 });
      // 隐藏悬浮框
      this.setData({
        showPopupFlag: false
      });
    },
     // 删除课程
  deleteCourse: function(event) {
    const index = event.currentTarget.dataset.index;
    const updatedCourses = this.data.courses.filter((_, i) => i !== index);
    this.setData({
      courses: updatedCourses
    });

    // 显示删除成功提示
    wx.showToast({
      title: '课程已删除',
      icon: 'success'
    });
  }
  });
  
  
  