Page({
    data: {
      phone: '',
      code: '',
      name: '',
      studentId: '',
      password: '',
      confirmPassword: '',
      isDisabled: false, // 控制按钮是否禁用
      buttonText: '获取验证码', // 按钮文本
      countdown: 60,  // 倒计时时间
      timer: null     // 定时器
    },
  
    onPhoneInput: function(e) {
      this.setData({
        phone: e.detail.value
      });
    },
  
    onCodeInput: function(e) {
      this.setData({
        code: e.detail.value
      });
    },
   // 获取验证码按钮点击事件
   onGetCode: function() {
    const that = this;

    // 禁用按钮，并开始倒计时
    this.setData({
      isDisabled: true,
      buttonText: `${this.data.countdown}s 已发送`
    });

    // 设置倒计时
    this.data.timer = setInterval(function() {
      let countdown = that.data.countdown - 1;
      that.setData({
        countdown: countdown,
        buttonText: `${countdown}s 验证码已发送`
      });

      if (countdown <= 0) {
        // 停止倒计时，恢复按钮状态
        clearInterval(that.data.timer);
        that.setData({
          isDisabled: false,
          buttonText: '获取验证码',
          countdown: 60  // 恢复倒计时
        });
      }
    }, 1000); // 每秒更新一次倒计时
  },

    onNameInput: function(e) {
      this.setData({
        name: e.detail.value
      });
    },
  
    onStudentIdInput: function(e) {
      this.setData({
        studentId: e.detail.value
      });
    },
  
    onPasswordInput: function(e) {
      this.setData({
        password: e.detail.value
      });
    },
  
    onConfirmPasswordInput: function(e) {
      this.setData({
        confirmPassword: e.detail.value
      });
    },
  
  
    onRegister: function() {
      const { phone, code, name, studentId, password, confirmPassword } = this.data;
  
      if (!phone || !code || !name || !studentId || !password || !confirmPassword) {
        wx.showToast({
          title: '请填写完整信息',
          icon: 'none'
        });
        return;
      }
      // 校验手机号是否为11位数字
    const phonePattern = /^[0-9]{11}$/;
    if (!phonePattern.test(phone)) {
      wx.showToast({
        title: '手机号必须为11位数字',
        icon: 'none'
      });
      return;
    }

    // 校验学号是否为12位数字
    if (studentId.length !== 12 || !/^[0-9]{12}$/.test(studentId)) {
      wx.showToast({
        title: '学号必须为12位数字',
        icon: 'none'
      });
      return;
    }
      if (password !== confirmPassword) {
        wx.showToast({
          title: '密码不一致',
          icon: 'none'
        });
        return;
      }
       // 存储用户信息到云数据库
    wx.cloud.database().collection('users').add({
        data: {
          phone: phone,
          jobId: studentId,
          password: password
        },
        success: res => {
          wx.showToast({
            title: '注册成功',
            icon: 'success'
          });
          // 注册成功后可以跳转到登录页
          wx.navigateTo({
            url: '/pages/teacher_logs/teacher_logs'
          });
        },
        fail: err => {
          wx.showToast({
            title: '注册失败',
            icon: 'none'
          });
        }
      });
    }
  });
  