// pages/student_join_class/student_join_class.js
Page({
    data: {
      classId: '',  // 存储输入的班级编号
      className: '', // 存储班级名称
      showPopupFlag: false,  // 控制弹出框显示
    },
  
    // 获取输入框中的班级编号
    onClassIdInput: function(e) {
      this.setData({
        classId: e.detail.value
      });
    },
  
    // 加入班级
    joinClass: function() {
      const { classId } = this.data;
  
      // 校验输入
      if (!classId) {
        wx.showToast({
          title: '请输入班级编号',
          icon: 'none'
        });
        return;
      }
  
      // 查询云数据库中的班级信息
      wx.cloud.database().collection('classes').where({
        id: classId
      }).get({
        success: res => {
          if (res.data.length === 0) {
            wx.showToast({
              title: '班级编号无效',
              icon: 'none'
            });
          } else {
            // 如果班级存在，显示加入成功并将班级信息展示
            const classData = res.data[0];
            this.setData({
              className: classData.name,
              showPopupFlag: false // 隐藏弹出框
            });
  
            wx.showToast({
              title: '已加入班级',
              icon: 'success'
            });
          }
        },
        fail: err => {
          wx.showToast({
            title: '查询失败',
            icon: 'none'
          });
        }
      });
    },
  
    // 点击显示加入班级弹窗
    showPopup: function() {
      this.setData({
        showPopupFlag: true
      });
    }
  });
  